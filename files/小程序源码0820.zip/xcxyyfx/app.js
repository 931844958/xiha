//app.js
App({
  GLOBAL:{
    userInfo:null,
    appID:'wx56220e590737d971',
    yyHTTP:'https://fish.vilicom.cn/fish_web/',
    //hgHTTP:'https://seadog.vilicom.cn/web_site/',
    hgHTTP:'https://fish.vilicom.cn/fish_ds_web_test/'
  },
  onLaunch: function () {}
})