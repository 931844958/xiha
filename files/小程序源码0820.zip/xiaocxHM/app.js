//app.js
App({
  GLOBAL:{
    userInfo:null,
    version:'v1',
    yyHTTP:'https://fish.vilicom.cn/fish_web/',
    hgHTTP:'https://seadog.vilicom.cn/web_site/',
  },
  onLaunch: function () {}
})